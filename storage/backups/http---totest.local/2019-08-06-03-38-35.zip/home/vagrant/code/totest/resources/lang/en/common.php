<?php
return [

    'Permission' => 'Permission',
    'Permissions' => 'Permissions',
    'Home' => 'Home',
    'Acl' => 'Acl',
    'Alias' => 'Alias',
    'Name' => 'Name',
    'Description' => 'Description',
    'Save' => 'Save',
    'Search' => 'Search',
    'New item' => 'New item',
    'Group' => 'Group',
    'Groups' => 'Groups',
    'Role' => 'Role',
    'Roles' => 'Roles'
    
];
