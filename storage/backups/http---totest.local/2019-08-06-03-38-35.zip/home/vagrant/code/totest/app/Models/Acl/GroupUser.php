<?php

namespace App\Models\Acl;

use Illuminate\Database\Eloquent\Model;

class GroupUser extends Model {

    protected $table = 'group_users';

}
