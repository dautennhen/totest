@extends('index')
@section('content')
<h2> purchase category</h2>
@endsection