@extends('index')
@section('content')
<h2> Dashboard </h2>
@endsection