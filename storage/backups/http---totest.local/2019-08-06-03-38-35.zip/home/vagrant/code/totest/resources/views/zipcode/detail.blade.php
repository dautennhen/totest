@extends('index')

@section('content')
zipcode {{$zipcode->zipcode}} <br />
city {{$zipcode->city}}
@endsection