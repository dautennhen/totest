<footer>
    <hr />
footer
</footer>
