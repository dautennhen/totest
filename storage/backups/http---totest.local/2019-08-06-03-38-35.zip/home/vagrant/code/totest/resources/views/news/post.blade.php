@extends('index')
@section('content')
<h2> news post</h2>
@endsection