@extends('index')
@section('content')
<h2> Social </h2>
@endsection