<?php

namespace App\Models\Acl;

use Illuminate\Database\Eloquent\Model;

class GroupRole extends Model {

    protected $table = 'group_role';

}
