<base href="{{ config('app.url') }}" />
<meta charset="utf-8">
<meta name="description" content="">
<meta name="author" content="lapnguyen">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Simple Solution</title>
<link rel="stylesheet" href="css/app.css" />
<script src="js/app.js"></script>
<script src="js/common.js"></script>