@extends('index')
@section('content')
<h2> news category</h2>
@endsection