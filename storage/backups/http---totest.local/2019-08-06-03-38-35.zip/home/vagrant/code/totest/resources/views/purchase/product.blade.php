@extends('index')
@section('content')
<h2> purchase product</h2>
@endsection