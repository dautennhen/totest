<h4 class="modal-title">@lang('common.Role')</h4>
<hr />
<div class="text-center text-danger form-edit-msg"></div>
<div>
    @lang('common.Alias') : {{ $item->alias }} <br />
    @lang('common.Name') : {{ $item->name }} <br />
    @lang('common.Description') : {{ $item->description }} <br />
</div>