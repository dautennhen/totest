<?php

namespace App\Http\Controllers\Admin\Acl;

class AclController extends Controller
{
    public function __construct() {
        
    }
    
    public function index()  {
        
    }
}